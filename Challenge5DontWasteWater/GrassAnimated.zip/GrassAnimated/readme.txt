GrassAnimated
By Sunchips

Description:
I got the inspiration from the animated grass found in the ultimate terraining map but wanted to make a version fitting my likings better. Tip: Tint the doodad in the world editor to get different colors (150 red 255 green 150 blue makes a good fores environment color)

[IMG]http://s17.postimage.org/z1vf757b1/Animated_Grass_Pic.gif[/IMG]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2012, October 19
Model was last updated 2012, October 22


Visit http://www.hiveworkshop.com for more downloads