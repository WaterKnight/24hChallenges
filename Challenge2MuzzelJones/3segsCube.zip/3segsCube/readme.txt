Fishing Hat
By MeteORA

Description:
A simple fishing hat for my fishing model pack. Scaled for a Villager unit. 

 Enjoy and give credits if you use it!

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, February 6


Visit http://www.hiveworkshop.com for more downloads