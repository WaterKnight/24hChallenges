Shades
By imforfun

Description:
If you have ever wanted some black shades, now you can have them! : D
Simple edit and re-texture of my glasses model.


(made for FirstLegacy who wanted black shades)

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2013, August 25
Model was last updated 2013, October 23


Visit http://www.hiveworkshop.com for more downloads