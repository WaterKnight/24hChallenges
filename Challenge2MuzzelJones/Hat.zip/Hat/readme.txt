Hat
By Lord-T-Rex

Description:
The ultimate Worms 3D for Warcraft 3 model pack!

 - Hat Attachment for head

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2008, May 2


Visit http://www.hiveworkshop.com for more downloads