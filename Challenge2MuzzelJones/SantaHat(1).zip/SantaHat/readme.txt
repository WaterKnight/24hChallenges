Santa Hat
By debode

Description:
[CENTER][SIZE=&quot;7&quot;][FONT=&quot;Century Gothic&quot;][color=#ff0000]M[/color][color=#ff3f3f]e[/color][color=#ff7f7f]r[/color][color=#ffbfbf]r[/color][color=#ffffff]y[/color] [color=#ffffff]C[/color][color=#ffdfdf]h[/color][color=#ffbfbf]r[/color][color=#ff9f9f]i[/color][color=#ff7f7f]s[/color][color=#ff5f5f]t[/color][color=#ff3f3f]m[/color][color=#ff1f1f]a[/color][color=#ff0000]s[/color] [color=#ff0033]2[/color][color=#ff3f66]0[/color][color=#ff7f99]0[/color][color=#ffbfcc]9[/color][color=#ffffff]![/color][/FONT][/SIZE][/CENTER]

A &quot;Santa Hat&quot; is a floppy, red hat trimmed in white fur traditionally worn during Christmas. 

It is team-colored. If you want team-color on it, use an ability like &quot;Life Regeneration Aura (Neutral)&quot; to attach it to the &quot;head&quot; attachment point. If you want it to be red, no matter the team of the unit, use an ability like &quot;Sphere&quot; to attach it. 

This is the &quot;classic&quot; version of the two Christmas head attachments I have submitted. The more &quot;medieval&quot; version can be found [url=&quot;http://www.hiveworkshop.com/forums/models-530/greathelm-winter-151807/&quot;]here[/url]. 


[size=&quot;1&quot;]Keep an eye open for robotz.[/size]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, December 5
Model was last updated 2009, December 5


Visit http://www.hiveworkshop.com for more downloads