HappyCockroach'sHelm
By Sin'dorei300

Description:
Happy Cockroach's Helmet from 
''Concept Art Mini-Contest ~ How would I be: My Helmet!'' :D
Reference: [url]http://www.hiveworkshop.com/forums/2202401-post119.html[/url]
All is scratch made, except the flower.

Changes:
V.1.1:
-Made the flower TC, too lazy to update the screenie

Enjoy, don't edit without permission and give credits! ;)

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2012, October 21
Model was last updated 2012, November 1


Visit http://www.hiveworkshop.com for more downloads