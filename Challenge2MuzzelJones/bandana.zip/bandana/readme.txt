bandana
By Chriz.

Description:
Model created for [url=&quot;http://www.hiveworkshop.com/forums/showthread.php?p=237074#post237074&quot;]Modeling Competition #1[/url]

[img]http://www.hiveworkshop.com/forums/images/misc/chriz_01.gif[/img]
Give credits if used. 

[b]Do not modify or redistribute without permission.[/b]

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 1970, January 01


Visit http://www.hiveworkshop.com for more downloads