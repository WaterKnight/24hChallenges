Chef's Hat
By RaidonGod

Description:
This is an very simple Chef hat. Every high ranked cook have this hat.^^
This is for an little minigame project of mine, but I will release it so all can have something of it. :D

Do not edit it.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, May 31


Visit http://www.hiveworkshop.com for more downloads