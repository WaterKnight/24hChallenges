HeroGlow
By assasin_lord

Description:
A simple attachable hero glow, just attach it to the units origin and you got a unit with glow.

Team colored and have alternative size for normal and large


Give me credit if you fell for it, because I can't stop you form using it if you don't

EDIT:
I'm terrible sorry but in later Wc3 versions this model won't work as I planned, apparently team-colored attachments won't change color anymore so this model is more or less fucked, I'm planning on making a full series of glows for each color but I'm not sure if it would be approved here so don't get your hopes up.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, May 29
Model was last updated 2009, May 29


Visit http://www.hiveworkshop.com for more downloads