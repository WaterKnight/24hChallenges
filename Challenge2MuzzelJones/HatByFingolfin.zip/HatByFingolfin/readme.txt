Military Hat
By Fingolfin

Description:
A little hat i made out of boredom.
This one is for General Frank. ;)

uses only ingame textures.


PS: I noticed there is a minor fuckup in the triangulation of the visor. It wont be visible in game, so i won't bother fixing it. Just so you know that i know.

Textures:
None

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, May 22


Visit http://www.hiveworkshop.com for more downloads