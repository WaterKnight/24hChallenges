Magic Hat
By xXMephistoXx

Description:
Made from scratch whith 3DSM5. Uses particles to &quot;get out the magic&quot; :P
Remember to give credits if you use it in your map, edit it as much as you want, but still give credits! :D

Textures:
Textures\MagicHatSkin.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 1969, December 31
Model was last updated 2007, April 28


Visit http://www.hiveworkshop.com for more downloads